package com.reservation.dto;




import lombok.Data;

@Data
public class SliderimagesDto {
		
	private int no;		
	private String filename;
	private String sortNo;
	private String Activity; // �ִ� �μ�
	private String deleteFlg;
	

	

	

}

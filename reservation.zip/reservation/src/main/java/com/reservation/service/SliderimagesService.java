package com.reservation.service;



import java.util.List;

import com.reservation.entity.SliderimagesEntity;



public interface SliderimagesService {	
	
	public List<SliderimagesEntity> findAll();
	
}

	
